---
name: "mtg-hooks-standard"
description: "Apply MTG's hooks, curiosity loop and CTA standard to any script, video, web copy, social post, headline, email, presentation or ad for MTG or mtgtribe.com."
---

# MTG 👑 Hooks & Creative Direction Standard

MTG 👑 | Your Digital Architect | mtgtribe.com

Companion to the mtg-creative-standard skill. That skill governs visual teaching, voice, music, preview and release. This one governs how content opens, holds attention, ends, and grows the MTG TRIBE. Apply both together. MTG's latest instruction in a chat always wins. Scale effort to the task: a one-line fix does not need the full process.

## 1. Scope and destination

Apply to everything created for MTG's brand: tutorials, explainers, promo and ad videos, websites and landing pages, blogs, social posts, headlines and titles, scripts and voiceovers, presentations and guides, CTAs, emails, banners and announcements, product and service descriptions, introductions, transitions and closings. Never settle for ordinary or generic when something more compelling is possible.

**Brand website for all hooks, CTAs, on-screen text and sign-offs: mtgtribe.com** (not MusaTheGiant.com). The goal of every piece of content is to bring people into the MTG TRIBE and grow MTG's social media platforms. Existing site URLs, referral links and media paths on current pages stay unchanged unless MTG asks.

## 2. Hooks

Open with a hook that gives a reason to keep reading, watching or listening. The phrases below are inspiration only. Understand the psychology and write fresh, context-specific variations. Never repeat them mechanically or reuse the same hook across a series.

| Type | Psychology | Examples |
|---|---|---|
| Curiosity | Opens a question the viewer wants closed | What if...? Imagine... Did you know...? Have you ever wondered...? What nobody is telling you about... Here's something most people don't realise... What happens when...? What if I told you...? |
| Pattern interrupt | Breaks autopilot scrolling | Stop scrolling for a second. Forget everything you know about... You're looking at this all wrong. Before you dismiss this, hear me out. Here's where things get interesting. Read that again! |
| Bold and provocative | Challenges an assumption | Here's an uncomfortable truth... Most people are missing something important... You're asking the wrong question. The biggest mistake you're making is... Let me challenge your thinking... The truth is hiding in plain sight. |
| Discovery and revelation | Promises insight | Here's what I just discovered... There's more to this than meets the eye. Here's the part nobody talks about... This could be the missing piece of the puzzle. Once you understand this, everything clicks. |
| Future-focused | Invites imagination | Imagine a world where... What if the future is already here? The next big shift might already be happening. A few years from now, this could be completely normal. The opportunities of tomorrow are being built today. |
| Suspense and anticipation | Keeps them to the next beat | But here's the twist... And that's where it gets interesting... What happens next might surprise you... The real story starts here... And that's not even the most interesting part... |

### Hype guardrail
Some hooks lean toward hype: "This changes everything", "Something extraordinary is happening", "We're witnessing the beginning of something extraordinary", "Here's what changes everything". Use them only when the content genuinely backs them up. Never attach them to earnings, returns, guaranteed results or a program's legitimacy. MTG's no-hype, no-income-promise and no "best ever" rules always apply.

## 3. The curiosity loop

Structure content, where appropriate, as:
1. **Attention:** a powerful opening.
2. **Curiosity:** a question, possibility or unexpected insight.
3. **Value:** useful information, education or entertainment.
4. **Revelation:** the most important discovery, benefit or takeaway.
5. **Action:** a meaningful next step, usually joining the MTG TRIBE or following a platform.

Never create unnecessary suspense or promise a revelation the content does not deliver. If a hook teases something, the content must pay it off.

Use mid-content re-hooks ("But here's the twist...", "And that's not even the most interesting part...") at natural turning points in longer videos and pages, not on every line.

## 4. CTAs

Go beyond "Click here", "Learn more" or "Sign up". Make CTAs benefit-driven, action-oriented and curiosity-provoking, and say clearly what to do and why it is worthwhile.

Examples: Discover what's possible. See how it works. Explore the future of digital finance. Take your first step into Web3. Don't just watch the revolution. Understand it. Ready to see what's happening beneath the surface? Start exploring today. Unlock your understanding. Find out what you've been missing.

Prefer specific CTAs tied to the content ("See how the matrix fills", "Watch where your Bitcoin actually goes") over generic ones. No aggressive, misleading or manipulative urgency.

## 5. Grow the MTG TRIBE and MTG's platforms

Whenever the moment fits, invite people into the tribe and onto MTG's platforms. One clear tribe CTA per piece, placed where the viewer has just received value; longer videos and pages may repeat it once near the end.

**Official destinations (use the ones that fit the platform; never invent a handle):**
- Tribe hub: **mtgtribe.com**
- WhatsApp tribe: **mtgtribe.com/group, the tribe call to action in every video and post** (MTG, 9 November 2026: "it drives traffic to my website, it drives traffic to my WhatsApp group, mtgtribe.com/group"). It is a page on MTG's own website that forwards to the WhatsApp group, so if WhatsApp ever suspends a group he changes where it points and every video still works. Never show or say the raw chat.whatsapp.com link. Order: the free tribe first, then mtgtribe.com; selling happens in the tribe and on the websites.
- YouTube: **https://www.youtube.com/@mtgtribe**
- TikTok: **https://www.tiktok.com/@joinmtgtribe**
- Telegram: **https://t.me/mtgtribe**
- Facebook: **https://www.facebook.com/mtgtribe**
- Direct WhatsApp messages and voice notes to MTG are welcome (no phone calls).

**The calls to action: the free MTG TRIBE at mtgtribe.com/group first, then mtgtribe.com** (MTG, 9 November 2026: grow the tribe, then sell), with a hint of what people find there: step-by-step tutorial videos, explainer videos and honest guides to multiple income streams (risks included). Match the platform for follows: on TikTok, point to YouTube; on YouTube, point to TikTok and Telegram; on websites, show all platforms in the footer and one primary tribe CTA in the content.

**Tribe positioning:** a diverse community of action takers who learn, execute and teach others; many opportunities and tools, not one program; open to everyone whatever they promote; built on knowledge, independence (own wallets, own transactions) and leading with value. Members are encouraged to start their own tribes.

**Tribe CTA examples (vary them):**
- "If this helped, there's more where it came from. Join the free MTG TRIBE at mtgtribe.com/group."
- "Don't learn this alone. The tribe is waiting at mtgtribe.com/group."
- "Action takers learn together. Come find your people at mtgtribe.com."
- "Follow @mtgtribe so the next video finds you first."
- "Save this, share it with someone who needs it, and join us at mtgtribe.com."

Pair tribe CTAs with the like, comment, save and share prompts already in MTG's standards. Never imply that joining guarantees income or results.

## 5a. Engagement and conversion: this is MTG's business (MTG, 7 Nov 2026)

"This is not a hobby. This is the serious business to me." Content must be fun, helpful and educational AND grow MTG's website traffic, sign-ups, sales, team and tribe. The full method lives in the **mtg-scriptforge** skill (`references/engagement-and-conversion.md`); these rules apply to every piece:

- **Give every piece a job:** one primary goal (reach, engagement, traffic, leads, sign-ups and sales, team or tribe growth) and the step of the viewer's journey it serves (discover, learn, trust, decide, grow). Move people one step forward, never from "just discovered you" straight to "sign up now".
- **Build in interaction:** questions that make people think and answer, a guess or a number to comment, a vote, a one-word takeaway, a specific person to share it with, reasons to like, save and follow. Long videos: 3 or 4 such moments (a prediction early that is paid off later, a reflection in the middle, a takeaway at the payoff, a share prompt at the end). Shorts: 1. Every prompt comes from the content and starts a real conversation; no empty "comment YES" bait (Facebook demotes it). Never ask for wallet addresses, recovery phrases, balances or account screenshots in comments.
- **Place website addresses strategically:** the one page that fits the topic, said short and slowly and shown on screen when the viewer has just received value (usually the payoff, about 75 to 90% through), plus the tribe. Every other link goes in the description, pinned comment and end card. One "go to this address" in the last 20 seconds. Exact live links with referral parameters unchanged, and the earnings disclosure when MTG can earn.
- **Fit the length to the job:** MTG's videos are vertical, 60 seconds or less when everything fits, up to 3 minutes when the topic is bigger (MTG, 10 Nov 2026: "videos can be up to 3 minutes long ... make it more compelling from start to finish"): 20 to 45 s for single facts and myths, 45 to 60 s for What If, Did You Know and short explainers, up to 3 minutes for rich topics, with the open loop renewed every 20 to 30 seconds and Leo's reactions at every emotional beat. Longer only when MTG asks (for example a click-by-click tutorial).
- **Speak to real people (MTG, 10 Nov 2026):** people who want to make money online, crypto and Bitcoin beginners, and full-time employees. For employees: compelling questions and real pain points (one income, a salary that runs out before the month, no time, job security) that lead to the idea of multiple streams of income, the tribe and mtgtribe.com. Respect their jobs: never shame, never promise an escape.
- **Made to be shared (MTG, 10 Nov 2026: "I want my videos to go viral"):** every video asks one specific person to receive it ("Send this to a friend who still doesn't get Bitcoin"), asks to save tip-heavy videos, asks a real question, then invites people into the tribe. Natural asks only, never rewards.
- **Close honestly:** say who it suits and who it does not, the risks, the fees and the real steps, and offer a personal line ("Not sure if it fits you? Send me a WhatsApp voice note."). No pressure, no fake deadlines, no income claims.
- **Stay platform-safe:** social platforms get education, trust and the tribe; compensation plans, recruitment, sign-up links into programs that pay from recruiting, returns, earnings proof and paid draws stay on MTG's websites and in the WhatsApp tribe. No "guaranteed", "risk-free", "double your money" or "get rich" wording anywhere, and no rewards for likes, comments or subscribes. Full gate: mtg-scriptforge `references/compliance.md`.
- **Ship and follow up:** every finished video gets a posting pack (titles, description with the main link in the first two lines, chapters, pinned comment, platform captions, WhatsApp tribe and status messages). After posting: pin the comment, answer early comments, share it in the tribe, turn the best questions into the next videos, and check the numbers weekly.

## 6. Adapt by format

| Format | Approach |
|---|---|
| Tutorials | Make them curious about what they will learn. Show the problem, guide the solution, show the successful result, then invite them to the tribe for the next one. |
| Explainers | Intriguing question, simplify the complex, deliver satisfying moments of understanding. |
| Ads | Lead with a problem, opportunity or benefit. Make the value clear fast. Strong CTA to mtgtribe.com. |
| Websites | Powerful headlines, benefit-focused subheadings, engaging intros, tribe CTAs placed where decisions happen. |
| Social | Short, punchy, scroll-stopping first line that invites watching, following, commenting, saving and sharing. |
| Educational | Make learning exciting. Turn complicated subjects into simple, memorable explanations. |
| Presentations | Open with a compelling thought, question, surprising insight or real-world scenario. |
| Closings | A memorable takeaway, an invitation to join the tribe, or a thought that stays. |

## 7. Brand voice

- Intelligent but easy to understand.
- Confident, authoritative and engaging.
- Educational without being boring.
- Persuasive without being pushy.
- Professional without sounding robotic.
- Conversational without losing credibility.
- Forward-thinking and innovation-focused.
- Concise, impactful and memorable.

Avoid jargon, corporate filler, repetitive introductions and predictable conclusions. Write for human beings first, not search engines. Never use em dashes or en dashes in any hook, headline, CTA or deliverable: use commas, colons, full stops or parentheses.

## 8. Video execution

Do not rely on narration alone. Reinforce every point with visuals, demonstrations, animation, diagrams, labels, transitions and on-screen text. Sync visuals to narration, use visual pattern interrupts to hold attention, highlight key words, demonstrate rather than describe, keep clear progression and strong pacing, and make it easy to follow on a phone. Show mtgtribe.com and the relevant platform icon on screen when the tribe CTA is spoken. Every scene has a purpose. Every video has a strong opening, meaningful progression and a satisfying conclusion. (Detailed visual, voice and music rules live in mtg-creative-standard.)

## 9. Quality control before presenting anything

1. Does the opening capture attention?
2. Does it create curiosity or communicate immediate value?
3. Is the message clear and easy to understand?
4. Does it offer something useful, interesting or memorable?
5. Does it hold engagement throughout?
6. Does it sound natural and human?
7. Does the CTA encourage a meaningful action, and point to the tribe (mtgtribe.com/group), mtgtribe.com or the right platform?
8. Is it consistent with MTG's brand?
9. Is every claim accurate and verifiable?
10. Could it be made significantly stronger?

If the answer to 10 is yes, improve it before presenting. Never sacrifice accuracy, clarity or credibility for engagement.

## 10. Think like a creative director

Do not execute mechanically. Ask:
- What would make someone stop scrolling?
- What would make them curious enough to continue?
- What would make them understand and remember it?
- What would make them trust it?
- What would make them want to join the tribe and follow?
- How could the same message land more powerfully?

Propose stronger headlines, alternative hooks, better storytelling and more compelling CTAs when useful. If an idea is weak, improve it rather than reproducing it.

## 11. The objective

People should stop, think, become curious, learn something valuable and, where appropriate, join the MTG TRIBE and follow along. Don't just create content. Create experiences that capture attention, communicate value, build trust and inspire action.

Let's Get This Crypto! 💪