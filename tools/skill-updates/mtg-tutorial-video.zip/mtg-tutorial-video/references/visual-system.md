# Visual system (vertical 1080 x 1920, every frame a pure function of time)

- Background #0b0912 with soft violet and gold glows and a faint grid. Fonts: Anton (display), Manrope 600 to 800.
- Top bar (y 58): the small JetUP logo disc in a 60 px circle with a gold ring (never MTG's face), "MTG" with "YOUR DIGITAL ARCHITECT" small in gold below it
  (part 2 onwards: short, so the website phone frame's camera island never covers it); lime "PART N" chip on the right.
- Step card (y 156 to 392): gold number tile, title 58 px with the exact on-screen label in a lime-outlined highlight,
  sub line 33 px, "STEP n OF N".
- Screen window x 70 to 1010, y 414 to 1636, radius 46, 5 px gold-titanium rim. The recording is zoomed 1.3 to 1.75 and
  the camera eases between key points. Never show a page without its context for long; show the address bar first.
- Rings: lime 6 px with glow, gold for "the result". Tap: dot 0.35 s before, then a ripple. Chips: 44 px, dark with lime
  edge, at the bottom of the window. Success chips start with the green tick emoji.
- Tip cards replace the window: "GOOD TO KNOW", the error message in quotes, two fixes with ticks.
- Plan panel (In this video and recap): Anton title, 9 rows of 98 px, gold number circles that turn into lime ticks.
- The JetUP logo disc (no MTG photo, MTG 8 Nov 2026): 576 px with a 9 px gold gradient ring and gold glow in the greeting;
  200 px top left with his name beside it in the recap and next-video scenes; in the ending, the training's gold circle card (`logo_card()` in `tools/video-signature/mtg_ending.py`). Source:
  `tools/jetup-tutorial/jetup-disc.png` (made from `jetup/img/jetup-logo-480.webp`).
- Captions y 1668: 50 px, the spoken word lime, numbers and addresses as people read them (12, mtgtribe.com/jetup, JetUP).
- Closing track starts T minus 51.36 s and ends on the last frame (videos longer than 60 s; see the rule in voice.md).
- Emoji pops (the training's): 84 px above the caption box at its right edge, 2 s, ease-back, on key words about every
  10 to 20 s (`TL.emos`, list per part in `tools/video-signature/emos/`). None after the ending starts.
- The ending (from "Everything I showed you" to the last frame) is the 9:09 sign-up training's, in Poppins with the
  training's colours, drawn over the stage background, top bar and captions: see SKILL.md section 3a. Content stays
  between y 170 and y 1640 so the captions (y 1668) are never covered.
